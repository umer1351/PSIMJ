<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->

<!-- Mirrored from annalskemu.org/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 31 May 2021 05:50:40 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="Annals,KEMU,King Edward Medical University, journal" />
    <meta name="description" content="" />
    <meta name="Author" content="IT Department KEMU" />

    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <!-- WEB FONTS : use %7C instead of | (pipe) -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400%7CRaleway:300,400,500,600,700%7CLato:300,400,400italic,600,700" rel="stylesheet" type="text/css" />
    <!-- CORE CSS -->
    <link href="<?php echo get_template_directory_uri(); ?>/classes/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <!-- THEME CSS -->
    <link href="<?php echo get_template_directory_uri(); ?>/classes/essentials.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo get_template_directory_uri(); ?>/classes/layout.css" rel="stylesheet" type="text/css" />
    <!-- PAGE LEVEL SCRIPTS -->
    <link href="<?php echo get_template_directory_uri(); ?>/classes/header-1.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo get_template_directory_uri(); ?>/classes/color_scheme/green.css" rel="stylesheet" type="text/css" id="color_scheme" />
    <!-- FAVICON -->
    <link rel='shortcut icon' type='image/x-icon' href='images/favicon.ico' />
    <!-- CUSTOM CSS FILES -->

    <title>Annals of KEMU</title>
    <?php wp_head(); ?>
</head>
<body class="boxed">

<!-- wrapper -->
<div id="wrapper" style="margin-top:-20px;;margin-bottom:0">

    <!-- Top Bar -->
    <div id="topBar">
        <div class="container">

            <!-- right -->
            <ul class="top-links list-inline pull-right">
                <li>
                    <a class="no-text-underline" role="button" href="">
                        Register
                        <!--<i class="fa fa-user-plus" aria-hidden="true"></i> Register-->
                    </a>

                </li>
                <li style="background:#660000;">
                    <a class="no-text-underline btn" role="button" href="" style="color:#fff">
                        <!--<i  class="fa fa-sign-in" aria-hidden="true"></i> Login</a>-->
                        Login</a>
                </li>

            </ul>

            <!-- left -->
            <ul class="top-links list-inline">
                <li class="hidden-xs"></li>
                <li class="text-welcome">
                    ISSN :2079-0694 (Online)
                </li>
                <li class="text-welcome">
                    2079-7192(Print)
                </li>
                <li class="text-welcome hidden-xs">
                    Previous ISSN :  1684-6680 (Annals of KEMC)</li>
                Last updated on 08/05/2021 09:37:26
            </ul>

        </div>
    </div>
    <!-- /Top Bar -->


    <style>

        /*homepage*/
        body
        {
            /*color: #000;*/
        }
        #topBar ul.top-links>li>a {
            padding: 6px 12px;}


        .hvr ul li{
            margin-bottom: 15px;border-bottom:1px solid #ccc;padding-bottom:2px;}
        .sub-content{
            border-bottom: 2px solid #e9e9e9;
            position: relative;
            margin-bottom: 30px;
        }
        .hvr ul li:last-child{
            margin-bottom: 1px !important;
            border-bottom:none !important;

        }
        h6.h-sub-content {
            display: inline-block;
            letter-spacing: 0.2px;
            font-size: 18px;
            text-transform: capitalize;
            border-bottom: 2px solid #e12121;
            line-height: 20px;
            margin-bottom: -2px;
            width: auto;
            max-width: 100%;

            font-family: 'Copperplate Gothic Light';

            font-weight: bold;
            text-align: justify;
            vertical-align: middle;
            color: #000000;



        }
        p h6.h-sub-content {
            margin: 0 0 20px 0;
            color: #424242;
            font-size: 15px;
            line-height: 24px;
            font-weight: 300;
            letter-spacing: 0.2px;
            text-align: left !important;

        }
        #topMain.nav-pills>li.active>a {
            color: #660000;
        }
        .h-sub-content	p{    margin-bottom:3px !important;margin-top:25px}

        .home img {
            margin-left: 7%;
            margin-top: 8%;
            max-height: 470px;
        }
        #footer>.container {
            padding: 30px 30px 10px 30px;

            margin-bottom: 10px;
            background: #2d2d2d;
            border-top: 8px solid #222;
        }
        #footer>.copyright {
            background-color: rgba(0,0,0,0.2);
            text-shadow: 1px 1px 1px rgba(0,0,0,0.1);
            padding: 5px 0;
            font-size: 13px;
            display: block;
        }
        #footer>.container p{text-align:justify;}
        #footer ul.footer-links>li {
            padding-bottom: 2px;

        }
        .badge {
            background-color: #fff;

            font-size:14px;
            margin-bottom:0px;
            padding: 0;
            color: #FF3300;
            text-transform: uppercase;
            font: bold 0.75em/1.15em Tahoma, Geneva, sans-serif;
        }
        .badge2{    background-color:#FFF8E8  ; padding: 0;}

        #header ul.nav-second-main {
            margin-top: 50px;    }


        .bdrright{
            border-right:1px solid #eee;
        }
        .logo img{
            max-height:60px !important;
            margin-left:-10px;}


        @media screen and (max-width: 768px) {
            #header ul.nav-second-main {
                margin-top: 15px;
            }
            .rightalign{

                margin-right:30px;

            }
            .bdrright{
                border-right:1px solid #fff;


            }
            .logo img{
                max-height:50px !important;}


        }
        @media screen and (max-width: 468px) {
            #header ul.nav-second-main {
                margin-top: 15px;
            }
            .logo img{
                max-height:42px !important;}


        }
        .homeicons .box-icon .box-icon-title>i {
            background-color: #660000;}
        /*
        header
        */

        #header{/* z-index: 10000; */
            width: 100%;
            background: #fff;
            border-bottom: 4px solid #f0f0f0;
            margin: 0;}
        #topBar ul.top-links li.text-welcome {
            color:black;
            font-size: 14px;
            margin-top: 10px;}


        .logo img{
            max-height:50px;}


        @media screen and (max-width: 480px) {
            #header ul.nav-second-main {
                margin-top: 15px;
            }
            #topBar ul.top-links li.text-welcome {
                padding: 0 2px;
                font-size: 12px;
            }
            .logo img{
                height:43px !important;}
            .homeicons .box-icon .box-icon-title > h2 {
                font-size: 14px;

            }
            @media screen and (max-width: 319px) {
                .logo img{
                    height:25px !important;margin-left:-10px;}
            }
        }
        #topMain.nav-pills>li>a {
            color: #1F262D;
            font-weight: 700;
            background-color: transparent;
            padding: 20px 16px 16px;
        }
        #topNav a.logo {
            height: 96px;
            line-height: 96px;
            overflow: hidden;
            display: inline-block;
            margin-left: 20px;
        }
        #topMain.nav-pills>li>a.dropdown-toggle:after { margin-top: 5px;}
        .hvr ul li {

            border-bottom: 1px solid #ccc;
            padding-bottom: 7px;
        }
        #header li.search .search-box {width:400px;    margin-top: 15px;}
        #header li.search .btn{margin-top: 25px;}
        @media screen and (max-width: 768px) {

            #header li.search .search-box {width:100%; top: 30px !important;}



        }
        /*#header.fixed {
           width: 87%;
           margin: auto;}/*

       /*Page level CSs*/

        .descrp p,ol{
            word-wrap: break-word;
            font-size: 17px;
            line-height: 1.6;
            COLOR: #000000;
            font-style: normal;
            text-align: justify;
            font-family: open_sansregular, Verdana,Arial, Helvetica, sans-serif;
        }
        .descrp h2 {
            font-size: 20px;
            font-weight: 600;
            COLOR: #000000;
            text-align: left;
            text-decoration: underline;
            FONT-FAMILY: open_sansregular, Verdana,Arial, Helvetica, sans-serif;}

        .descrp a{
            font-family: open_sansregular, Verdana,Arial, Helvetica, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #039BE5;
            text-align: left;
            outline: none;
            text-decoration: underline;
            cursor: auto;
        }

        .fa-stack-2x {
            color: #660000;
        }

        @media only screen and (max-width: 480px){

            #header #topNav a.logo>img {
                max-height: 35px !important;
            }
    </style>



    <div id="header" class="sticky clearfix">

        <!-- TOP NAV -->
        <header id="topNav">
            <div class="container">

                <!-- Mobile Menu Button -->
                <button class="btn btn-mobile" data-toggle="collapse" data-target=".nav-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- BUTTONS -->
                <ul class="pull-right nav nav-pills nav-second-main">

                    <!-- SEARCH -->
                    <li class="search">
                        <a href="javascript:;">
                            <i class="fa fa-search"></i>
                        </a>
                        <div class="search-box">


                            <form class="form-inline" role="form" id="simpleSearchForm" action="">
                                <div class="form-group">
                                    <label for="simpleQuery">Search</label>
                                    <input type="text" class="form-control" id="simpleQuery" name="simpleQuery" size="15" maxlength="255" value="" placeholder="Search ....    ">
                                </div>
                                <div class="form-group">
                                    <label for="searchField">Search Scope</label>
                                    <select id="searchField" name="searchField"  class="form-control required valid">
                                        <option label="All" value="query">All</option>
                                        <option label="Authors" value="authors">Authors</option>
                                        <option label="Title" value="title">Title</option>
                                        <option label="Abstract" value="abstract">Abstract</option>
                                        <option label="Index terms" value="indexTerms">Index terms</option>
                                        <option label="Full Text" value="galleyFullText">Full Text</option>
                                    </select>
                                </div>

                                <button type="submit" value="Search" class="btn btn-primary">Search</button>
                            </form>
                        </div>
                    </li>
                    <!--SEARCH -->


                </ul>
                <!-- /BUTTONS -->


                <!-- Logo -->
                <a class="logo pull-left" href="">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/logo_dark.png" alt="" />
                </a>


                <div class="navbar-collapse pull-right nav-main-collapse collapse">
                    <nav class="nav-main">


                        <ul id="topMain" class="nav nav-pills nav-main">
                            <li class="dropdown active"><!-- HOME -->
                                <a href="">
                                    Home
                                </a>

                            </li>
                            <li class="dropdown">
                                <!-- About -->
                                <a class="dropdown-toggle" href="#">
                                    About
                                </a>
                                <ul class="dropdown-menu">

                                    <li><a href="about.php">History</a></li>
                                    <li><a href="members.php">Editorial Board</a></li>

                                    <li>
                                        <a href="aimsscope.php">Aims & Scope</a>
                                    </li>

                                    <li>
                                        <a href="files/Plagiarism%20Policy%20of%20King%20Edward%20Medical%20University.pdf">Intellectual Property Rights</a>
                                    </li>

                                    <!-- <li>
                                       <a href="statistics.php">
                                         Web Statistics

                                       </a>
                                     </li>-->
                                    <li>
                                        <a class="dropdown-toggle" href="#">
                                            Media Gallery

                                        </a>

                                    </li>
                                    <li>
                                        <a href="contact.php">
                                            Contact Us

                                        </a>
                                    </li>
                                </ul>
                            </li>


                        </ul>
                        </li>

                        </ul>

                    </nav>
                </div>

            </div>
        </header>
        <!-- /Top Nav -->

    </div>




    <!-- /wrapper -->



    <div id="sidepanel" class="sidepanel-light">
        <a id="sidepanel_close" href="#"><!-- close -->
            <i class="glyphicon glyphicon-remove"></i>
        </a>

        <div class="sidepanel-content">
            <h2 class="sidepanel-title">Akemu</h2>

            <!-- SIDE NAV -->
            <ul class="list-group">

                <li class="list-group-item">
                    <a href="#">
                        <i class="ico-category et-heart"></i>
                        ABOUT US
                    </a>
                </li>
                <li class="list-group-item list-toggle"><!-- add "active" to stay open on page load -->
                    <a data-toggle="collapse" data-parent="#sidebar-nav" href="#collapse-1" class="collapsed">
                        <i class="ico-dd icon-angle-down"><!-- Drop Down Indicator --></i>
                        <i class="ico-category et-strategy"></i>
                        PORTFOLIO
                    </a>
                    <ul id="collapse-1" class="list-unstyled collapse"><!-- add "in" to stay open on page load -->
                        <li><a href="#"><i class="fa fa-angle-right"></i> 1 COLUMN</a></li>
                        <li class="active">
                            <span class="badge">New</span>
                            <a href="#"><i class="fa fa-angle-right"></i> 2 COLUMNS</a>
                        </li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> 3 COLUMNS</a></li>
                    </ul>
                </li>
                <li class="list-group-item list-toggle"><!-- add "active" to stay open on page load -->
                    <a data-toggle="collapse" data-parent="#sidebar-nav" href="#collapse-2" class="collapsed">
                        <i class="ico-dd icon-angle-down"><!-- Drop Down Indicator --></i>
                        <i class="ico-category et-trophy"></i>
                        PORTFOLIO
                    </a>
                    <ul id="collapse-2" class="list-unstyled collapse"><!-- add "in" to stay open on page load -->
                        <li><a href="#"><i class="fa fa-angle-right"></i> SLIDER</a></li>
                        <li class="active"><a href="#"><i class="fa fa-angle-right"></i> HEADERS</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> FOOTERS</a></li>
                    </ul>
                </li>
                <li class="list-group-item">
                    <a href="#">
                        <i class="ico-category et-happy"></i>
                        BLOG
                    </a>
                </li>
                <li class="list-group-item">
                    <a href="#">
                        <i class="ico-category et-beaker"></i>
                        FEATURES
                    </a>
                </li>
                <li class="list-group-item">
                    <a href="#">
                        <i class="ico-category et-map-pin"></i>
                        CONTACT
                    </a>
                </li>

            </ul>
            <!-- /SIDE NAV -->

            <!-- social icons -->
            <div class="text-center margin-bottom-30">

                <a href="#" class="social-icon social-icon-sm social-facebook" data-toggle="tooltip" data-placement="top" title="Facebook">
                    <i class="icon-facebook"></i>
                    <i class="icon-facebook"></i>
                </a>

                <a href="#" class="social-icon social-icon-sm social-twitter" data-toggle="tooltip" data-placement="top" title="Twitter">
                    <i class="icon-twitter"></i>
                    <i class="icon-twitter"></i>
                </a>

                <a href="#" class="social-icon social-icon-sm social-linkedin" data-toggle="tooltip" data-placement="top" title="Linkedin">
                    <i class="icon-linkedin"></i>
                    <i class="icon-linkedin"></i>
                </a>

                <a href="#" class="social-icon social-icon-sm social-rss" data-toggle="tooltip" data-placement="top" title="RSS">
                    <i class="icon-rss"></i>
                    <i class="icon-rss"></i>
                </a>

            </div>
            <!-- /social icons -->

        </div>

    </div>
    <!-- /SIDE PANEL -->







