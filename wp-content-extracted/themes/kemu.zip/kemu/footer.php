<footer id="footer" >
    <div class="container">

        <div class="row">

            <div class="col-md-4" style="padding:20px;">


                <!-- Contact Address -->
                <address>
                    <ul class="list-unstyled">
                        <li class="footer-sprite address">
                            King Edward Medical University,<br>
                            Lahore,54000<br>
                            Pakistan<br>
                        </li>
                        <li class="footer-sprite phone">
                            Phone: +92 (42) 99211145-53
                        </li>
                        <li class="footer-sprite email">
                            <a href="mailto:publications@kemu.edu.pk">publications@kemu.edu.pk</a>
                        </li>
                    </ul>
                </address>
                <!-- /Contact Address -->

            </div>
            <div class="col-md-4">

                <!-- Links -->
                <h4 class="letter-spacing-1" style="    border-bottom: 1px solid #212121;margin-bottom:10px;">
                    Quick Links</h4>
                <ul class="footer-links list-unstyled">

                    <li><a href="">Current Issue</a></li>
                    <li><a href="">Archives</a></li>
                    <li><a href="">Video Tutorial</a></li>
                    <li><a href="Downloads/Letter%20of%20Authorship(Both%20Forms%20are%20Compulsory).zip">Letter of Authorship</a></li>
                    <li><a href="Downloads/Review%20Policy.pdf">Review Policy</a></li>
                    <li><a href="Downloads/Qualitative%20Guidelines.pdf">Qualitative Guidelines</a></li>
                    <li><a href="Downloads/Annals%20Submission%20Guidlines%20in%20PowerPoint%20Presentation.ppsx">Submission Guidelines</a></li>
                    <li><a href="https://kemu.edu.pk/">KEMU Website</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
                <!-- /Links -->

            </div>
            <div class="col-md-4">

                <!-- Disclaimer -->
                <h4 class="letter-spacing-1" style="    border-bottom: 1px solid #212121;margin-bottom:10px;">Disclaimer</h4>
                <ul class="footer-posts list-unstyled">
                    <li>
                        <p style="margin-bottom:5px;">
                            All articles published in the Annals of KEMU represent the views of the authors and do not reflect any official policy of the Annals. All rights are reserved with the Annals. No part of the journal may be reproduced by any form or by any means without written permission from the Editor.



                        </p>
                    </li>

                </ul>
                <!-- /Disclaimer -->


                <!-- Latest Blog Post -->
                <h4 class="letter-spacing-1" style="    border-bottom: 1px solid #212121;margin-bottom:10px;">Annual Subscription Rates (Print Version)</h4>
                <ul class="footer-links list-unstyled">
                    <li>
                        <a>
                            Inland within Pakistan: Rs. 2,000.00



                        </a>
                    </li>
                    <li>
                        <a>
                            International: US$ 100.00



                        </a>
                    </li>

                </ul>
                <!-- /Latest Blog Post -->


            </div>





        </div>

    </div>

    <div class="copyright">
        <div class="container" style="text-align:center;">

            &copy; All Rights Reserved, King Edward Medical University Lahore.
        </div>
    </div>
</footer>
<style type="text/css">
    a {
        cursor: pointer !important;
    }
</style>
<!-- PRELOADER
<div id="preloader">
<div class="inner">
<span class="loader"></span>
</div>
</div> /PRELOADER -->

<!-- SCROLL TO TOP -->
<a href="#" id="toTop"></a>
<!--
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>-->

<!-- JAVASCRIPT FILES -->

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery-2.1.4.min.js"></script>
<!--<script type="text/javascript">
    $(window).on('load',function(){
        $('.bs-example-modal-lg').modal('show');
    });
</script>-->
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/classes/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/scripts.js"></script>

<!-- <script src="js/vendor/jquery-1.9.1.min.js"></script>-->


<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.eu01.nr-data.net","licenseKey":"NRJS-50257918abbcb4537bb","applicationID":"131313631","transactionName":"MhBSZQoZWhAHVBAICQtaZUMRV10NAlIcTxYNBQ==","queueTime":0,"applicationTime":3,"atts":"HldRE0IDSR4=","errorBeacon":"bam.eu01.nr-data.net","agent":""}</script></body>

<?php wp_footer(); ?>
</body>

<!-- Mirrored from annalskemu.org/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 31 May 2021 05:51:02 GMT -->
</html>
