<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

get_header();
?>

<div class="container" style="background-color:white;">

    <style type="text/css">
        .articlelist{
            border-right: 2px solid  #333;
            font-family: "Times New Roman", Times, serif !important;
            color: #333;
            font-size: 9px;
            margin-right: 2px;
            padding: 0 2px 0 2px !important;
            border-bottom: none !important;
            display: inline;


        }
        .articlelist a{ color: #FF3300 !important;}
        .articlelist2 a{ color: #FF3300 !important;}
        .articlelist2{
            font-family: "Times New Roman", Times, serif !important;

            color: #333;
            font-size: 9px;
            margin-right: 2px;
            padding: 0 5px 0 2px !important;
            border-bottom: none !important;
            display: inline;
        }
        .ulwid{
            padding-top: 5px !important;
            padding-bottom: 20px !important;

        }

        .ulwid2{

            padding-bottom: 20px !important;
            padding-top:1px !important;


        }
        .ulwid3{
            padding-top: 12px !important;
            padding-bottom: 20px !important;
        }

        .marginads{
            margin-bottom: 1px !important;
        }


    </style>

    <div class="row" style="    padding: 1%;">



        <div class="col-md-12 col-sm-12 col-xm-12" >
            <div class="sub-content">
                <h6 class="h-sub-content">
                    <p >
                        <strong>
                            LATEST RESEARCH (VOL 27, ISSUE 1 - 2021)
                        </strong>

                    </p>
                </h6>
            </div>
        </div>


        <div class="col-md-4 col-sm-6 col-xm-12" >
            <div class="latest-blog-posts hvr">
                <div style="background-color:#FFF8E8;border:1px solid #eee">
                    <ul class="latest-posts bdrright" style="padding:5px 3% 1px 3%;">

                        <span class="badge badge2">EDITORIAL</span><br />
                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4391">
                                COVID-19 Vaccines
                            </a>
                            <br /><span>Saira Afzal, Mehreen Nasir</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4391">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4391/2512">PDF</a>

                                </li>
                            </ul>

                        </li>
                        <span class="badge badge2">GUEST EDITORIAL</span><br />
                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4392">
                                Seven-Flag Approach to Total Sanitation: Sharing Results of a Pilot in Nepali Schools
                            </a>
                            <br /><span>Sudan Raj Panthi, Hyder Khurshid Alam, Ehsanullah Tarin</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4392">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4392/2513">PDF</a>

                                </li>

                            </ul>

                        </li>
                        <span class="badge badge2">GUEST EDITORIAL</span><br />
                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4393">
                                COVID-19 Infection
                            </a>
                            <br /><span>Waqar Haider Gaba</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4393">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4393/2514">PDF</a>

                                </li>

                            </ul>

                        </li>

                        <span class="badge badge2">LETTERS TO EDITORS</span><br />
                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4424">
                                The Impact of Covid-19: A Pandemic after Effects in Institutions of Pakistan
                            </a>
                            <br /><span>Asma Aleem, Maria idrees, Maria Gul, et al.
					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4424">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4424/2537">PDF</a>
                                </li>
                            </ul>
                        </li>
                        <span class="badge badge2">CASE REPORTS</span><br />
                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4418">
                                Clouston’s Syndrome-A Case Report
                            </a>
                            <br /><span>Ghazala Butt, Abdul Latif, Usma Ifthkhar,  et al.
					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4418">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4418/2531">PDF</a>

                                </li>
                            </ul>

                        </li>

                        <span class="badge badge2">PERSPECTIVES</span><br />
                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4419">
                                Intensive Care Unit Management of the COVID-19
                            </a>
                            <br /><span>Saad Javed, Shahzaib Ahmad, Zermeen Naveed, et al.

					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4419">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4419/2532">PDF</a>
                                </li>
                            </ul>
                        </li>


                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4420">
                                Uncommon Presentations of COVID-19
                            </a>
                            <br /><span>Muhammad Adnan Aasim, Muhammad Fayzan Mehmood, Arsal Gill, et al.

					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4420">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4420/2533">PDF</a>
                                </li>
                            </ul>
                        </li>

                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4421">
                                Lung Cancer Services and the COVID-19 Pandemic
                            </a>
                            <br /><span>Tehseen Haider, Abdul Raheem Arshad, Abdullah Arshad, et al.

					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4421">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4421/2534">PDF</a>
                                </li>
                            </ul>
                        </li>
                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4422">
                                Covid-19 and How it has Changed Research
                            </a>
                            <br /><span>Muhammad Abubakar Shahid Chishti, Shahzaib Farid, Anum Sohail, et al.

					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4422">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4422/2535">PDF</a>
                                </li>
                            </ul>
                        </li>
                        <li class="ulwid marginads 27-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4423">
                                Psychological Effects of COVID-19
                            </a>
                            <br /><span>Salma Yousaf, Rabeea Ahmed, Afzal Javed

					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4423">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4423/2536">PDF</a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </div>

                <!--COLUMN 1-->
                <ul class="latest-posts bdrright" style="padding:5px 3%;">

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid 27-1--1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4416">
                            Covid-19: From Pandemic to Epidemic an Ostrich Syndrome Causing Desensitization among Urban and Suburban Masses
                        </a>
                        <br /><span>
				Bushra Naz, Muhammad Kashif Fida, Muhammad Zohaib Khan, et al.
			</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4416">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4416/2530">PDF
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>

            </div>
        </div>

        <!--COLUMN 2 -->
        <div class="col-md-4 col-sm-6 col-xm-12" >
            <div class="latest-blog-posts hvr ">
                <ul class="latest-posts bdrright" style="padding:5px 3%;">

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4394">
                            Body Image Dissatisfaction in Healthy Medical Students and its Association to Body Mass Index, Gender and Age
                        </a>
                        <br /><span>
					Filza Saeed, Rabia Munir, Saira Tariq, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4394">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4394/2515">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4395">
                            Microbiological Diagnosis of Osteoarticular Infections and their Antibiogram
                        </a>
                        <br /><span>
					Shumaila Jabbar, Fiaz Ahmad, Maryam Khan,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4395">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4395/2516">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4396">
                            Coronary Artery Disease in Young Pakistanis: Risk Factors and Pattern of Disease
                        </a>
                        <br /><span>
					Muzaffar Ali, Usman Mahmood Butt, Rao Shahzad Abdul Tawwab Khan,   et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4396">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4396/2517">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4398">
                            Psychosocial Issues in Women with Primary Infertility: A Psychometric Study
                        </a>
                        <br /><span>
					Sadia Saleem, Arjumand Shaheen, Ayesha Jabeen, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4398">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4398/2518">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4405">
                            Causes and Management Outcome of Subcutaneous Emphysema in a Busy Thoracic Surgery Unit at Teaching Hospital, Karachi
                        </a>
                        <br /><span>
					Pratikshya Thapaliya, Tanveer Ahmad, Khalil Ahmed Sheikh, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4405">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4405/2523">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4406">
                            Significance of Histopathological Examination in Hysterectomy Specimens Operated for Clinically Diagnosed Uterine Prolapse
                        </a>
                        <br /><span>
					Kanwal Babar, Asifa Noreen, Naveed Qureshi,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4406">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4406/2524">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4410">
                            Changing Presentation of Traumatic Brain Injuries in a Tertiary Hospital Lahore Following Enforcement of Motorcycle Helmet Laws - A Mixed-Method Study
                        </a>
                        <br /><span>
					Mohammad Suleman Bajwa, Saima Hamid, Muhammad Mohsin Iqbal,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4410">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4410/2526">PDF</a>
                            </li>
                        </ul>
                    </li>


                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4413">
                            The Adaptation and Validation of Resilience Scale for HIV Patients
                        </a>
                        <br /><span>
					Faiza Nayyer, Iffat Batool
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4413">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4413/2527">PDF</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>

        <!--COLUMN 3-->
        <div class="col-md-4 col-sm-6 col-xm-12" >
            <div class="latest-blog-posts hvr">
                <ul class="latest-posts" style="padding:5px 3%;">

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4399">
                            The outcome of Hang-Back Sutures Technique in Horizontal Strabismus Surgery
                        </a>
                        <br /><span>
					Umair Tariq Mirza, Zahid Kamal Siddiqui
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4399">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4399/2519">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4400">
                            Etiological Analysis of Pancytopenia in a Tertiary Care Hospital
                        </a>
                        <br /><span>
					Asma Saadia, Adeela Shahid, Muhammad Shahid Saeed,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4400">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4400/2520">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4401">
                            Determinants of Underweight School Children in Lahore
                        </a>
                        <br /><span>
					Adeela Shahid, Ayesha Sadiqa, Muhammad Shahid Saeed,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4401">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4401/2521">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4402">
                            Assessment of Left Ventricular Systolic Function After Acute Anterior Wall Myocardial Infarction Treated with Primary Percutaneous Coronary Intervention at 24 Hours and 6 Weeks After the Procedure
                        </a>
                        <br /><span>
					Ammar Akhtar, Tariq Mehmood Khan, Badar Ul Ahad Gill, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4402">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4402/2522">PDF</a>
                            </li>
                        </ul>
                    </li>


                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4407">
                            Determinants of Adherence to cDMARDs in Patients of Rheumatoid Arthritis at a Tertiary Care Hospital of Lahore, Pakistan
                        </a>
                        <br /><span>
					Javed Iqbal, Aflak Rasheed, Tafazzul H. Mahmud, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4407">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4407/2525">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4414">
                            An Updated Systematic Review and Meta-Analysis to Determine the Association between Iron Deficiency Anemia and Helicobacter Pylori Infection in Low and Middle Income Countries
                        </a>
                        <br /><span>
					Hassan Ali, Kiran Fatima, Khunsa Junaid,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4414">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4414/2528">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="27-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4415">
                            Different Radiological Patterns on Plain Chest X-Ray in COVID-19 Patients
                        </a>
                        <br /><span>
					Nawaz Rashid, Iqbal Hussain Dogar, Mahjabeen Masood,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4415">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/4415/2529">PDF</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>

    </div>


    <div class="text-center">
        <a href="" class="btn btn-primary btn-lg margin-top-20 margin-bottom-20"  style="display: block; width: 100%;">View More</a>
    </div>









    <style type="text/css">
        .articlelist{
            border-right: 2px solid  #333;
            font-family: "Times New Roman", Times, serif !important;
            color: #333;
            font-size: 9px;
            margin-right: 2px;
            padding: 0 2px 0 2px !important;
            border-bottom: none !important;
            display: inline;


        }
        .articlelist a{ color: #FF3300 !important;}
        .articlelist2 a{ color: #FF3300 !important;}
        .articlelist2{
            font-family: "Times New Roman", Times, serif !important;

            color: #333;
            font-size: 9px;
            margin-right: 2px;
            padding: 0 5px 0 2px !important;
            border-bottom: none !important;
            display: inline;
        }
        .ulwid{
            padding-top: 5px !important;
            padding-bottom: 20px !important;

        }

        .ulwid2{

            padding-bottom: 20px !important;
            padding-top:1px !important;


        }
        .ulwid3{
            padding-top: 12px !important;
            padding-bottom: 20px !important;
        }

        .marginads{
            margin-bottom: 1px !important;
        }


    </style>

    <div class="row" style="    padding: 1%;">



        <div class="col-md-12 col-sm-12 col-xm-12" >
            <div class="sub-content">
                <h6 class="h-sub-content">
                    <p >
                        <strong>
                            PREVIOUS RESEARCH (VOL 26, SPECIAL ISSUE 2020)
                        </strong>

                    </p>
                </h6>
            </div>
        </div>


        <div class="col-md-4 col-sm-6 col-xm-12" >
            <div class="latest-blog-posts hvr">
                <div style="background-color:#FFF8E8;border:1px solid #eee">
                    <ul class="latest-posts bdrright" style="padding:5px 3% 1px 3%;">

                        <span class="badge badge2">EDITORIAL</span><br />
                        <li class="ulwid marginads 26-1--1"><a href="">
                                The Journey from Medical Nihilism to Pandemic Preparedness for COVID-19: A Global Health Challenge
                            </a>
                            <br /><span>Saira Afzal, Khalid Masud Gondal</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="">PDF</a>

                                </li>
                            </ul>

                        </li>
                        <span class="badge badge2">GUEST EDITORIAL</span><br />
                        <li class="ulwid marginads 26-1--1"><a href="">
                                Challenges to Treat Cancer Patients During COVID-19 Pandemic
                            </a>
                            <br /><span>Muhammad Wasif Saif</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="">PDF</a>

                                </li>

                            </ul>

                        </li>


                        <span class="badge badge2">LETTERS TO EDITORS</span><br />
                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3654">
                                The Psychological Impact of COVID-19 Pandemic on Pakistani Population: Managing Challenges through Mental Health Services
                            </a>
                            <br /><span>Khunsa Junaid, Hassan Ali, Rabia Nazim
					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3654">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3654/2226">PDF</a>
                                </li>
                            </ul>
                        </li>
                        <span class="badge badge2">EXPERT OPINION</span><br />
                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3616">
                                Obstetric Care in COVID-19: Strategy in a Tertiary Care Setting
                            </a>
                            <br /><span>Shamsa Humayun, Saima Chaudhary, Nuzhat Malik,  et al.
					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3616">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3616/2195">PDF</a>

                                </li>
                            </ul>

                        </li>
                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3615">
                                Future Impacts of COVID-19 Infection on Pakistani Population
                            </a>
                            <br /><span>Riffat Mehboob, Mahvish Kabir, Syed Amir Gilani,   et al.
					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3615">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3615/2194">PDF</a>

                                </li>
                            </ul>

                        </li>
                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3614">
                                Sociocultural and Religious Factors Associated with Varied Response in General Public in Pakistan Regarding COVID-19
                            </a>
                            <br /><span>Ghazala Butt, Ijaz Hussain
					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3614">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3614/2193">PDF</a>

                                </li>
                            </ul>

                        </li>
                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3617">
                                Challenges as Opportunities: Adapting Tele-Education for Physicians Collaborative Response to COVID-19 Pandemic
                            </a>
                            <br /><span>Danish Bhatti, Waleed Zafar, Shahid Rafiq
					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3617">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3617/2196">PDF</a>
                                </li>
                            </ul>
                        </li>

                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3618">
                                Operating Facilities:- Suggested Guidelines to Cope COVID-19 in Third World Countries
                            </a>
                            <br /><span>Muhammad Saleem, Uzma Ather, Azka Saleem, et al.
					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3618">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3618/2197">PDF</a>
                                </li>
                            </ul>
                        </li>


                        <span class="badge badge2">MEDICAL HUMANITIES</span><br />
                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3655">
                                Teacher, Scholar, Mentor, Friend: Prof. Dr. Faisal Masud
                            </a>
                            <br /><span>Syed Asghar Naqi

					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3655">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3655/2227">PDF</a>
                                </li>
                            </ul>
                        </li>


                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3656">
                                As is a Tale, so is Life: Not How Long it is, But How Good it is, is What Matters Seneca; A Tribute to Dr Faisal Masud
                            </a>
                            <br /><span>Ayesha Najib

					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3656">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3656/2228">PDF</a>
                                </li>
                            </ul>
                        </li>

                        <li class="ulwid marginads 26-1--1"><a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3657">
                                In Memoriam – Dr Faisal Masud (1954-2019)
                            </a>
                            <br /><span>Ali Madeeh Hashmi

					</span><br />
                            <ul style="float:right;">
                                <li class="articlelist">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3657">Full Text</a>
                                </li>
                                <li class="articlelist2">
                                    <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3657/2229">PDF</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <!--COLUMN 1-->
                <ul class="latest-posts bdrright" style="padding:5px 3%;">




                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid 26-1--1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3644">
                            Role of Social Media in Diagnosis and Management of COVID-19; An Experience of a Pulmonologist
                        </a>
                        <br /><span>
				Muhammad Waseem, Nauman Aziz
			</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3644">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3644/2216">PDF
                                </a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid 26-1--1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3645">
                            The Corona Conundrum: A Shadow Pandemic of Mental Health Concerns
                        </a>
                        <br /><span>
				Romesa Qaiser Khan, Zara Farooq, Abdul Moiz Khan
			</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3645">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3645/2217">PDF
                                </a>
                            </li>
                        </ul>
                    </li>
                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid 26-1--1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3646">
                            COVID-19: Lab Testing: Review Article
                        </a>
                        <br /><span>
					Waheed Uz Zaman Tariq, Omar Rasheed Chughtai			</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3646">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3646/2218">PDF
                                </a>
                            </li>
                        </ul>
                    </li>

                </ul>

            </div>
        </div>

        <!--COLUMN 2 -->
        <div class="col-md-4 col-sm-6 col-xm-12" >
            <div class="latest-blog-posts hvr ">
                <ul class="latest-posts bdrright" style="padding:5px 3%;">

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3622">
                            Impact on Frontline Nurses in the Fight Against Coronavirus Disease
                        </a>
                        <br /><span>
					Ahsan Sethi, Hira Shireen Aamir, Bilal Ahmed Sethi, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3622">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3622/2198">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3623">
                            A Qualitative Study of Psychological Impact on Mothers of Children with COVID- 19 in Hospital Setting
                        </a>
                        <br /><span>
					Irum Aamer, Sumbul Liaqat, Salma Malik, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3623">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3623/2199">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3624">
                            Role of Telemedicine in Management of Surgical Patients During COVID-19 Lockdown: A Solution to Reduce Footprints in Surgical Outpatient Clinics
                        </a>
                        <br /><span>
					Ayesha Shuakat, Muhammad Asad Saleem, Ghazanfar Ali,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3624">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3624/2200">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3631">
                            Psychological Impacts of Social Distancing During COVID-19 Pandemic in Adolescents of Lahore, Pakistan
                        </a>
                        <br /><span>
					Saima Majeed, Mujeeba Ashraf
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3631">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3631/2205">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3632">
                            Psychosocial Effects of COVID-19 on Health Care Workers: A Cross Sectional Study from Tertiary Level Pediatric Hospital
                        </a>
                        <br /><span>
					Nabila Talat, Muhammad Kamran Azam, Muhammad Bilal Mirza, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3632">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3632/2206">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3638">
                            Variations in Clinical Parameters of Hospitalized Patients with COVID-19
                        </a>
                        <br /><span>
					Omair Farooq, Mohammad Khan, Atika Masood, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3638">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3638/2210">PDF</a>
                            </li>
                        </ul>
                    </li>


                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3637">
                            Spectrum of High Resolution Computed Tomography Findings in COVID-19 Infection
                        </a>
                        <br /><span>
					Verda Ashraf, Saman Chaudhry, Khalid Rehman Yousaf, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3637">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3637/2209">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3640">
                            A Bibliometric Study of Infectious Diseases Research in Pakistan (2000-2020): A Call for Increased Productivity
                        </a>
                        <br /><span>
					Ahmad Azam Malik, Hina Mahmood, Nadeem Shafique Butt, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3640">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3640/2212">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3641">
                            Diagnosis and Treatment of Cytokine Storming as a Management of COVID-19 Infection
                        </a>
                        <br /><span>
					Mahvish Kabir, Riffat Mehboob, Syed Amir Gilani,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3641">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3641/2213">PDF</a>
                            </li>
                        </ul>
                    </li>
                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3647">
                            SARS-CoV-2: Cytokine Storm and Therapy
                        </a>
                        <br /><span>
					Mir Ibrahim Sajid, Javeria Tariq, Shehar Bano Awais,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3647">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3647/2219">PDF</a>
                            </li>
                        </ul>
                    </li>
                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid2" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3648">
                            Depression Among Healthcare Workers During the COVID-19 Pandemic in Low and Middle-Income Countries: A Systematic Review
                        </a>
                        <br /><span>
					Khunsa Junaid, Hassan Ali, Rabia Nazim
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3648">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3648/2220">PDF</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>

        <!--COLUMN 3-->
        <div class="col-md-4 col-sm-6 col-xm-12" >
            <div class="latest-blog-posts hvr">
                <ul class="latest-posts" style="padding:5px 3%;">

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3625">
                            Effect of COVID-19 Pandemic on Mental Wellbeing of Healthcare Workers in Tertiary Care Hospital
                        </a>
                        <br /><span>
					Tayyiba Wasim, Gul e Raana, Natasha Bushra,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3625">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3625/2201">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3627">
                            Features of Corona Virus in Confirmed Elderly Patients in Lahore: Comparison with Young and Middle Aged
                        </a>
                        <br /><span>
					Muhammad Imran Hassan Khan, Muhammad Maqsood, Abdul Basit,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3627">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3627/2202">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3629">
                            Practices of General Public Towards Personal Protective Measures During the Coronavirus Pandemic
                        </a>
                        <br /><span>
					Khadija Zubair, M. Luqman, Farhat Ijaz,  et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3629">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3629/2203">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3630">
                            'Surviving COVID-19': Illness Narratives of Patients and Family Members in Pakistan
                        </a>
                        <br /><span>
					Taskeen Mansoor, Sawera Mansoor, Usama bin Zubair
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3630">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3630/2204">PDF</a>
                            </li>
                        </ul>
                    </li>
                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3634">
                            Risk Perception of COVID-19 Among Pregnant Females
                        </a>
                        <br /><span>
					Yasmeen Muhammad Din, Shamila Ijaz Munir, Sadia Abdul Razzaq, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3634">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3634/2207">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">ORIGINAL ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3635">
                            A Bumpy Road to Online Teaching: Impact of COVID-19 on Medical Education
                        </a>
                        <br /><span>
					Anbreen Aziz, Sidra Aamer, Asma Munir Khan, et al.
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3635">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3635/2208">PDF</a>
                            </li>
                        </ul>
                    </li>


                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3639">
                            Evolving Role of Radiology in COVID-19 Pandemic: A Review
                        </a>
                        <br /><span>
					Sarwat Hussain
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3639">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3639/2211">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3642">
                            COVID-19 and Diabetes Mellitus: Prevalence and Precautions
                        </a>
                        <br /><span>
					Mohammad Zahidul Iqbal, Benazeer Zohra
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3642">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3642/2214">PDF</a>
                            </li>
                        </ul>
                    </li>
                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3643">
                            Surgical Practice During the COVID-19 Pandemic: An Update
                        </a>
                        <br /><span>
					Saadia Nosheen Jan, Muhammad Mustehsan Bashir, Romaisa Shamim Khan
				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3643">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3643/2215">PDF</a>
                            </li>
                        </ul>
                    </li>

                    <span class="badge">REVIEW ARTICLE</span><br />
                    <li class="ulwid3" id="26-1">
                        <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3649">
                            Sanitization Walk-Through Gates During COVID-19 Pandemic: Effective or A False Sense of Protection?
                        </a>
                        <br /><span>
					Adeel Gardezi, Farooq Azam Rathore, Fareeha Farooq

				</span><br />
                        <ul style="float:right;">
                            <li class="articlelist">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3649">Full Text</a>
                            </li>
                            <li class="articlelist2">
                                <a href="https://www.annalskemu.org/journal/index.php/annals/article/view/3649/2221">PDF</a>
                            </li>
                        </ul>
                    </li>


                </ul>
            </div>
        </div>

    </div>


    <div class="text-center">
        <a href="https://www.annalskemu.org/journal/index.php/annals/issue/archive" class="btn btn-primary btn-lg margin-top-20 margin-bottom-20"  style="display: block; width: 100%;">View More</a>
    </div>









    <div class="row"  style="background: white; padding: 1%;">
        <div class="col-md-12 col-sm-12 col-xm-12">
            <div class="sub-content">
                <h6 class="h-sub-content">
                    <p >
                        <strong>
                            IMPORTANT LINKS
                        </strong>

                    </p>
                </h6>
            </div>
        </div>  </div>

    <div class="row text-center services" style="background: white;padding: 1%;">
        <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-user-plus fa-stack-1x fa-inverse"></i>
                        </span>
            <h4><a href="journal/index.php/annals/user/register.html">Register Here</a></h4>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
                    <span class="fa-stack fa-4x">
                         <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-sign-in fa-stack-1x fa-inverse"></i>
                        </span>
            <h4><a href="journal/index.php/annals/author/submit.html">New Submission</a></h4>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
                    <span class="fa-stack fa-4x">
                            <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-film fa-stack-1x fa-inverse"></i>
                        </span>
            <h4><a href="journal/index.php/annals/issue/view/130.html">Current Issue</a></h4>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
                    <span class="fa-stack fa-4x">
                           <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-file-archive-o fa-stack-1x fa-inverse"></i>
                        </span>
            <h4> <a href="journal/index.php/annals/issue/archive.html">Archives</a></h4>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
                    <span class="fa-stack fa-4x">
                             <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-list-alt fa-stack-1x fa-inverse"></i>
                        </span>
            <h4> <a href="authors.html">Instructions for Authors</a></h4>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
                    <span class="fa-stack fa-4x">
                          <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-clipboard fa-stack-1x fa-inverse"></i>
                        </span>
            <h4><a href="reviewers.html">Instructions for Reviewers</a></h4>
        </div>

    </div>


    <!-- Past Issues -->
    <section class="padding-top-10 padding-bottom-10" style="padding: 1%;">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xm-12" >
                <div class="sub-content">
                    <h6 class="h-sub-content">
                        <p >
                            <strong>
                                PAST <strong>ISSUES</strong>
                            </strong>

                        </p>
                    </h6>
                </div>
            </div>  </div>
        <div class="row">
            <div class="col-md-6 col-sm-12 col-xm-12" >
                <ul class="list-unstyled">
                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/127">
                            <span class="pull-right text-black size-14">July - September 2020</span>
                            VOLUME 26 - ISSUE 3
                        </a>
                    </li>
                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/123">
                            <span class="pull-right text-black size-14">April - June 2020</span>
                            VOLUME 26 - ISSUE 2
                        </a>
                    </li>
                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/113">
                            <span class="pull-right text-black size-14">January - March 2020</span>
                            VOLUME 26 - ISSUE 1
                        </a>
                    </li>
                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/112">
                            <span class="pull-right text-black size-14">October - December 2019</span>
                            VOLUME 25 - ISSUE 4
                        </a>
                    </li>


                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/111">
                            <span class="pull-right text-black size-14">July - September 2019</span>
                            VOLUME 25 - ISSUE 3
                        </a>
                    </li>




                </ul>

            </div>
            <div class="col-md-6 col-sm-12 col-xm-12" ><ul class="list-unstyled">

                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/109">
                            <span class="pull-right text-black size-14">April - June 2019</span>
                            VOLUME 25 - ISSUE 2
                        </a>
                    </li>
                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/107">
                            <span class="pull-right text-black size-14">January - March 2019</span>
                            VOLUME 25 - ISSUE 1
                        </a>
                    </li>
                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/106">
                            <span class="pull-right text-black size-14">October - December 2018</span>
                            VOLUME 24 - ISSUE 4
                        </a>
                    </li>

                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/105">
                            <span class="pull-right text-black size-14">July - September 2018</span>
                            VOLUME 24 - ISSUE S
                        </a>
                    </li>
                    <li class="clearfix border-bottom-dotted relative margin-bottom-10">
                        <a class="clearfix size-20 block relative padding-10" href="https://www.annalskemu.org/journal/index.php/annals/issue/view/102">
                            <span class="pull-right text-black size-14">April - June 2018</span>
                            VOLUME 24 - ISSUE 2
                        </a>
                    </li>




                </ul>
            </div>
        </div>

        <div class="text-center">

            <a href="journal/index.php/annals/issue/archive.html" class="btn btn-primary btn-lg margin-top-20"  style="display: block; width: 100%;">View More</a>
        </div>
    </section>
    <!-- /Past Issues -->




    <div class="row" style="background: white; padding: 1%;">
        <div class="col-md-4 col-sm-12 col-xm-12 home rightalign" style="padding:20% auto; margin-bottom:10px;" >
            <a href="https://www.annalskemu.org/journal/index.php/annals/index">
                <img class="img-responsive" src="images/annalskemu.jpg" style="" alt="Annals Kemu" >
            </a>
        </div>
        <div class="col-md-8 col-sm-12 col-xm-12" style="padding:1px 5%;">

            <div class="sub-content" style="margin-bottom: 2px;">
                <h6 class="h-sub-content">
                    <p>
                        <strong>
                            RESEARCH GATE STATISTICS
                        </strong>

                    </p>
                </h6>
            </div>
            <div class="researchgate rightalign">
                <div class="rg-plugin" data-type="institution" data-stats="true" data-faces="false" data-publications="true" data-width="720" data-height="450" data-theme="light" data-installationId="5701e17e48954c7f1c429196" style="margin-left:-8px;margin-bottom:0; margin-top:0 !important;width:100%"></div>
            </div>
        </div>  </div>




    <div class="row" style="background: white; padding: 1%;">
        <div class="col-md-12 col-sm-12 col-xm-12" >
            <div class="sub-content">
                <h6 class="h-sub-content">
                    <p >
                        <strong>
                            ANNALS KEMU IS INDEXED ON
                        </strong>

                    </p>
                </h6>
            </div>
        </div>  </div>

    <div style="background: white; padding: 1%;">
        <ul class="row clients-dotted list-inline" >
            <li class="col-md-3 col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive" src="images/Directory%20of%20Open%20Access%20Journals%20(DOAJ).jpg" alt="client" />
                </a>
            </li>
            <li class="col-md-3 col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive" src="images/ebscohost-research-databases.png" alt="client" />
                </a>
            </li>
            <li class="col-md-3 col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive" src="images/EMRO%20Indexus%20Medicus%20of%20WHO.gif" alt="client" />
                </a>
            </li>
            <li class="col-md-3 col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive" src="images/Google%20Scholar.jpg" alt="Google Scholar" />
                </a>
            </li>
            <li class="col-md-3 col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive" src="images/Open%20Archives%20Initiative.gif" alt="pen Archives Initiative" />
                </a>
            </li>
            <li class="col-md-3 col-sm-3 col-xs-6 nobdr">
                <a href="#">
                    <img class="img-responsive" src="images/Pak%20MediNet.gif" alt="Pak MediNet" />
                </a>
            </li>
            <li class="col-md-3 col-sm-3 col-xs-6 nobdr">
                <a href="#">
                    <img class="img-responsive" src="images/PKP%20Harvester%20Database.png" alt="PKP" />
                </a>
            </li>
            <li class="col-md-3 col-sm-3 col-xs-6 nobdr">
                <a href="#">
                    <img class="img-responsive" src="images/ResearchGate.png" alt="ResearchGate" />
                </a>
            </li>


            <li class="col-md-6 col-sm-6 col-xs-6 nobdr" style="border-bottom:1px dashed rgba(0,0,0,0.3);max-height: 100px;">
                <a href="http://theadl.com/content.php">
                    <img class="img-responsive" src="images/ADL.png" alt="ADL" />
                </a>
            </li>
            <li class="col-md-6 col-sm-6 col-xs-6 nobdr" style="border-bottom:1px dashed rgba(0,0,0,0.3);max-height: 100px;">
                <a href="#">
                    <img class="img-responsive" src="images/clarivate.png" alt="Clarivate" />
                </a>
            </li>

        </ul>
    </div>

</div>




<?php
get_footer();

