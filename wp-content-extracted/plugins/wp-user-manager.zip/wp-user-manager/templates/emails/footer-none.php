<?php
/**
 * This is a fake email template used by the email previewer only.
 */
?>
</body>
</html>
