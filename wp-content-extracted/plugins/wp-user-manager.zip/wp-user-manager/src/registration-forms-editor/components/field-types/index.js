import FieldRepeater from './wpum-field-repeater'

export default [ FieldRepeater ]
